"""Step 3 + 4: train baseline model and evaluate. Run from project root."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))

import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from preprocess import clean

df = pd.read_csv("classifier/tickets.csv").dropna().drop_duplicates()
df["text_clean"] = df["text"].map(clean)

X_train, X_test, y_train, y_test = train_test_split(
    df["text_clean"], df["label"], test_size=0.2, stratify=df["label"], random_state=42
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
    ("clf", LogisticRegression(max_iter=1000, class_weight="balanced")),
])
model.fit(X_train, y_train)

pred = model.predict(X_test)
print(classification_report(y_test, pred))
print("Confusion matrix:\n", confusion_matrix(y_test, pred, labels=model.classes_))
print("Classes:", list(model.classes_))

joblib.dump(model, "classifier/model.joblib")
print("Saved classifier/model.joblib")
