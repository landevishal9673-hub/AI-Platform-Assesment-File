"""Step 2: preprocessing."""
import re

EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE = re.compile(r"\+?\d[\d\s().-]{8,}\d")
CARD = re.compile(r"\b(?:\d[ -]*?){13,16}\b")


def clean(text: str) -> str:
    text = str(text).lower()
    text = CARD.sub(" <card> ", text)     # mask PII BEFORE storing/training
    text = EMAIL.sub(" <email> ", text)
    text = PHONE.sub(" <phone> ", text)
    text = re.sub(r"http\S+", " <url> ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text
