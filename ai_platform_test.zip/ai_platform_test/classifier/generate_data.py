"""Step 1: create a small synthetic dataset (replace with real tickets in production)."""
import random
import pandas as pd

random.seed(42)

TEMPLATES = {
    "billing": [
        "I was charged twice for my {thing} this month",
        "Please refund my last payment, the amount is wrong",
        "My invoice shows an extra fee I don't understand",
        "How do I update my credit card for the {thing}?",
        "I cancelled but I'm still being billed",
    ],
    "technical_issue": [
        "The app crashes every time I open the {thing} page",
        "I get error 500 when I try to upload a file",
        "Login is not working after the latest update",
        "The {thing} feature is very slow and keeps timing out",
        "I can't connect to the API, it returns a timeout",
    ],
    "general_inquiry": [
        "What are your business hours?",
        "Do you offer a student discount on the {thing}?",
        "Can you tell me more about the {thing} plan?",
        "Where can I find your documentation?",
        "Is there a mobile app available?",
    ],
}
THINGS = ["subscription", "dashboard", "premium", "report", "account", "checkout"]

rows = []
for label, temps in TEMPLATES.items():
    for _ in range(200):
        text = random.choice(temps).format(thing=random.choice(THINGS))
        if random.random() < 0.3:  # add a little noise
            text += random.choice([" Please help!", " urgent", " thanks", " ASAP"])
        rows.append({"text": text, "label": label})

pd.DataFrame(rows).sample(frac=1, random_state=1).to_csv("classifier/tickets.csv", index=False)
print("Saved classifier/tickets.csv", len(rows), "rows")
