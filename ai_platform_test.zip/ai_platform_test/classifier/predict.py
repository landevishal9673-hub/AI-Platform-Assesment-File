"""Step 5: inference with a confidence threshold + human-review fallback."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))

import joblib
from preprocess import clean

THRESHOLD = 0.60
model = joblib.load("classifier/model.joblib")


def classify(message: str) -> dict:
    probs = model.predict_proba([clean(message)])[0]
    best = probs.argmax()
    conf = float(probs[best])
    label = model.classes_[best] if conf >= THRESHOLD else "needs_human_review"
    return {"label": label, "confidence": round(conf, 3)}


if __name__ == "__main__":
    msg = " ".join(sys.argv[1:]) or "I was billed twice this month"
    print(classify(msg))
