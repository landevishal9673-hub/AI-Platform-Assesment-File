# Deployment Guide
To deploy a service, run `make deploy ENV=staging`. Production deploys require
approval from two reviewers and must be done during the Tuesday/Thursday release window.
Rollbacks are done with `make rollback VERSION=<previous_version>`.

# On-call
The on-call engineer must acknowledge PagerDuty alerts within 10 minutes.
Escalate to the team lead if an incident lasts longer than 30 minutes.
