"""RAG step 1: load docs -> chunk by section -> embed -> save index. Run from project root."""
import glob, json, os, re
import numpy as np
from sentence_transformers import SentenceTransformer

EMBED_MODEL = "all-MiniLM-L6-v2"


def chunk(text, max_words=150):
    # one chunk per markdown section; long sections are split further
    sections = [s.strip() for s in re.split(r"\n(?=#)", text) if s.strip()]
    chunks = []
    for s in sections:
        words = s.split()
        for i in range(0, len(words), max_words):
            chunks.append(" ".join(words[i:i + max_words]))
    return chunks


def main():
    chunks, meta = [], []
    paths = glob.glob("chatbot/data/docs/*.md") + glob.glob("chatbot/data/docs/*.txt")
    for path in paths:
        text = open(path, encoding="utf-8").read()
        for i, c in enumerate(chunk(text)):
            chunks.append(c)
            meta.append({"source": os.path.basename(path), "chunk": i, "text": c})

    model = SentenceTransformer(EMBED_MODEL)
    emb = model.encode(chunks, normalize_embeddings=True)
    np.save("chatbot/index.npy", emb)
    json.dump(meta, open("chatbot/meta.json", "w"))
    print(f"Indexed {len(chunks)} chunks")


if __name__ == "__main__":
    main()
