# AI Platform Engineer – Candidate Evaluation

I chose **Scenario 1 (Support-message classifier)** and **Scenario 2 (Engineering chatbot / RAG)**.

## How to run
```bash
pip install -r requirements.txt
# Scenario 1
python classifier/generate_data.py   # synthetic data (swap in real tickets)
python classifier/train.py           # train + evaluate
python classifier/predict.py "I was charged twice"
# Scenario 2
export ANTHROPIC_API_KEY=...         # any LLM provider works; swap the client call
python chatbot/ingest.py             # chunk + embed docs in chatbot/data/docs
python chatbot/bot.py
```

---
# Scenario 1 – Support Message Classifier

## Data needed
- Historical tickets/chats/emails (message text, subject, channel, timestamp) with the category agents assigned.
- Labeling guideline (what is "billing" vs "technical"), 500–1000+ examples per class.
- Metadata that may help: product, customer tier, language.
- Privacy: PII masked before storage/training (done in `preprocess.py`).

## Preprocessing
1. Drop empties/duplicates; strip email signatures, quoted reply chains, HTML.
2. Mask PII (emails, phones, card numbers, URLs).
3. Lowercase, normalise whitespace; keep punctuation/numbers that carry signal (e.g. "error 500").
4. Language detection; route non-English separately or use a multilingual model.
5. Stratified train/val/test split (split by customer/time to avoid leakage).

## Model choice (staged, simplest first)
| Stage | Model | Why |
|---|---|---|
| Baseline (built) | TF-IDF + Logistic Regression | Fast, cheap, explainable, strong on short text, trains in seconds |
| Upgrade | Fine-tuned DistilBERT / multilingual-E5 embeddings + LR | Better on paraphrases, typos, multiple languages |
| Cold-start / new categories | LLM zero/few-shot with JSON output | No labeled data needed; use also to bootstrap labels |
I would only move up a stage if the evaluation shows the baseline is not good enough, because cost and latency rise each step.

## What the real solution looks like
```
Ticket arrives (email/chat/API) -> preprocess + PII mask -> classifier service (FastAPI)
  -> confidence >= threshold ? route to queue (Billing/Tech/General) : "needs_human_review"
  -> log prediction + agent correction -> feedback table -> weekly retrain
```
- Containerised REST endpoint (`POST /classify`), model versioned in a registry.
- Low-confidence predictions go to a human; agent corrections become new training data (active learning loop).
- Monitoring: prediction distribution drift, confidence histogram, override rate.

## Evaluation
- Per-class precision/recall/F1 and macro-F1 (accuracy hides imbalance); confusion matrix.
- Cost-weighted view: e.g. billing->technical misroutes are costlier than general->billing.
- Hold-out test set from the *latest* time period; calibration check of probabilities.
- Online: A/B or shadow mode, then track agent override rate and time-to-first-response.

## Risks
- Class imbalance, noisy/inconsistent labels, ambiguous multi-intent messages (use multi-label if needed).
- Concept drift (new products, outages), new categories appearing.
- Data leakage (duplicate threads across train/test); PII/privacy compliance.
- Over-trusting a 100% score on synthetic data: real data will be much messier.

---
# Scenario 2 – Chatbot for Engineers (RAG)

## End-to-end architecture
```
Docs (Confluence, wiki, Git READMEs, runbooks, tickets)
   -> Ingestion pipeline: parse -> clean -> chunk (~120-300 words, overlap) -> embed
   -> Vector store (FAISS/pgvector; here numpy) + metadata (source, owner, updated_at, ACL)
User question -> (optional query rewrite) -> embed -> top-k retrieval (+ rerank)
   -> Similarity gate -> Prompt builder -> LLM -> Citation verifier -> Answer + sources
   -> Logging, thumbs up/down feedback, eval dashboard
```
Production additions: scheduled re-indexing, access control filtering at retrieval time (engineers only see docs they are allowed to), hybrid search (BM25 + vectors) for exact identifiers like error codes, caching, conversation memory.

## Prompt design (see `SYSTEM_PROMPT` in `bot.py`)
- Role + strict rule: answer only from `<context>`.
- Exact refusal sentence when context is insufficient.
- Mandatory citations `[file#chunk]`.
- Context wrapped in tags and treated as data, which reduces prompt injection from documents.
- temperature=0 for consistency.

## Guardrails against hallucination
1. **Retrieval gate:** if best similarity < threshold, don't call the LLM, say "I don't know".
2. **Grounded prompt:** only-use-context rule + explicit refusal path.
3. **Citation verification:** reject answers whose citations are not in retrieved chunks.
4. **Hybrid search + reranker** to improve retrieval quality (most hallucinations start as bad retrieval).
5. **Evaluation set:** 50–100 Q&A pairs incl. unanswerable questions; measure faithfulness, answer relevance, refusal accuracy (e.g. RAGAS, or LLM-as-judge plus human spot checks).
6. **Feedback loop + freshness:** show doc last-updated date, thumbs down -> review queue, re-index on doc change.
7. **Safety:** PII/secrets filter on input and output, rate limiting, audit logs.

## Known limits of this demo
Numpy cosine search (swap for a vector DB at scale), fixed-size chunking (use heading-aware chunking), no reranker or conversation memory.
